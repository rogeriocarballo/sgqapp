﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;


namespace SGQWebApplication.Models
{
    public class NaoConformidade
    {
        [Key]
        [Display(Name = "Código")]
        public int Nc_id { get; set; }

        [Display(Name = "Descrição do Problema")]
        public string? Descricao_problema { get; set; }

        [Display(Name = "Data do Problema")]
        public DateTime? Data_problema { get; set; }

        [Display(Name = "Causa Raiz do Problema")]
        public string? Causa_raiz { get; set; }

        [Display(Name = "Causador")]
        public string? Causador { get; set; }

        [Display(Name = "Responsável pelo Tratamento")]
        public string? Responsavel_tratamento { get; set; }

        [Display(Name = "Área Impactada")]
        public string? Area_impactada { get; set; }

        [Display(Name = "Modelo do Veículo")]
        public string? Modelo_veiculo { get; set; }

        [Display(Name = "Marca do Veículo")]
        public string? Marca_veiculo { get; set; }

        [Display(Name = "Ano do Veículo")]
        public string? Ano_veiculo { get; set; }
    }
}
