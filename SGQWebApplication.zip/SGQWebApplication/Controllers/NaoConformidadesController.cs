﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SGQWebApplication.Data;
using SGQWebApplication.Models;

namespace SGQWebApplication.Controllers
{
    public class NaoConformidadesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public NaoConformidadesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: NaoConformidades
        public async Task<IActionResult> Index()
        {
            return View(await _context.NaoConformidade.ToListAsync());
        }

        // GET: NaoConformidades/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var naoConformidade = await _context.NaoConformidade
                .FirstOrDefaultAsync(m => m.Nc_id == id);
            if (naoConformidade == null)
            {
                return NotFound();
            }

            return View(naoConformidade);
        }

        // GET: NaoConformidades/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: NaoConformidades/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Nc_id,Descricao_problema,Data_problema,Causa_raiz,Causador,Responsavel_tratamento,Area_impactada,Modelo_veiculo,Marca_veiculo,Ano_veiculo")] NaoConformidade naoConformidade)
        {
            if (ModelState.IsValid)
            {
                _context.Add(naoConformidade);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(naoConformidade);
        }

        // GET: NaoConformidades/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var naoConformidade = await _context.NaoConformidade.FindAsync(id);
            if (naoConformidade == null)
            {
                return NotFound();
            }
            return View(naoConformidade);
        }

        // POST: NaoConformidades/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Nc_id,Descricao_problema,Data_problema,Causa_raiz,Causador,Responsavel_tratamento,Area_impactada,Modelo_veiculo,Marca_veiculo,Ano_veiculo")] NaoConformidade naoConformidade)
        {
            if (id != naoConformidade.Nc_id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(naoConformidade);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!NaoConformidadeExists(naoConformidade.Nc_id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(naoConformidade);
        }

        // GET: NaoConformidades/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var naoConformidade = await _context.NaoConformidade
                .FirstOrDefaultAsync(m => m.Nc_id == id);
            if (naoConformidade == null)
            {
                return NotFound();
            }

            return View(naoConformidade);
        }

        // POST: NaoConformidades/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var naoConformidade = await _context.NaoConformidade.FindAsync(id);
            _context.NaoConformidade.Remove(naoConformidade);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool NaoConformidadeExists(int id)
        {
            return _context.NaoConformidade.Any(e => e.Nc_id == id);
        }
    }
}
