﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace SGQWebAPI.Models
{
    public class NaoConformidade
    {
        [Key]
        public int Nc_id { get; set; }
        public string? Descricao_problema { get; set; }
        public DateTime? Data_problema { get; set; }
        public string? Causa_raiz { get; set; }
        public string? Causador { get; set; }
        public string? Responsavel_tratamento { get; set; }
        public string? Area_impactada { get; set; }
        public string? Modelo_veiculo { get; set; }
        public string? Marca_veiculo { get; set; }
        public string? Ano_veiculo { get; set; }
    }
}
