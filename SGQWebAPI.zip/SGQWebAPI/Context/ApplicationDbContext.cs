﻿using SGQWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace SGQWebAPI.Context
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
         : base(options)
        {
        }

        public DbSet<NaoConformidade>? NaoConformidade { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Conexão Local:
            // optionsBuilder.UseSqlServer(@"Server=.;Database=DBSGQ001;Integrated Security=True");

            // Conexão Servidor Web:
            // optionsBuilder.UseSqlServer(@"workstation id=DBSGQ001.mssql.somee.com;packet size=4096;user id=rogercarb1_SQLLogin_1;pwd=ud9vs25rmq;data source=DBSGQ001.mssql.somee.com;persist security info=False;initial catalog=DBSGQ001"); 

            optionsBuilder.UseSqlServer(@"Server=.;Database=DBSGQ001;Integrated Security=True");
        }
    }

}



