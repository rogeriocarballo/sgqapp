﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SGQWebAPI.Models;
using SGQWebAPI.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace SGQWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NaoConformidadeController : ControllerBase
    {
        private ILogger _logger;
        private INaoConformidadeService _service;

        public NaoConformidadeController(ILogger<NaoConformidadeController> logger, INaoConformidadeService service)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet("/api/nc")]
        public ActionResult<List<NaoConformidade>> GetNaoConformidade()
        {
            return _service.GetNaoConformidade();
        }

        [HttpGet("/api/nc/{id}")]
        public ActionResult<NaoConformidade> GetNaoConformidade(int id)
        {
            return _service.GetNaoConformidade(id);
        }

        [HttpPost("/api/nc")]
        public ActionResult<NaoConformidade> AddNaoConformidade(NaoConformidade naoconformidade)
        {
            _service.AddNaoConformidade(naoconformidade);
            return naoconformidade;
        }

        [HttpPut("/api/nc/{id}")]
        public ActionResult<NaoConformidade> UpdateNaoConformidade(int id, NaoConformidade naoconformidade)
        {
            _service.UpdateNaoConformidade(id, naoconformidade);
            return naoconformidade;
        }

        [HttpDelete("/api/nc/{id}")]
        public ActionResult<int> DeleteNaoConformidade(int id)
        {
            _service.DeleteNaoConformidade(id);
            return id;
        }
    }
}
