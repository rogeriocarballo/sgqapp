﻿using SGQWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SGQWebAPI.Services
{
    public interface INaoConformidadeService
    {
        public List<NaoConformidade> GetNaoConformidade();
        public NaoConformidade GetNaoConformidade(int id);
        public void AddNaoConformidade(NaoConformidade naoconformidade);
        public void UpdateNaoConformidade(int id, NaoConformidade naoconformidade);
        public void DeleteNaoConformidade(int id);
    }
}
