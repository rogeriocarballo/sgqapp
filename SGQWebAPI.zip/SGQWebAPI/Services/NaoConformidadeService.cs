﻿using SGQWebAPI.Models;
using SGQWebAPI.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SGQWebAPI.Services
{
    public class NaoConformidadeService : INaoConformidadeService
    {
        public ApplicationDbContext _context;

        public NaoConformidadeService()
        {
            var optionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();
            optionsBuilder.UseSqlServer("name=ConnectionStrings:DefaultConnection");

            _context = new ApplicationDbContext(optionsBuilder.Options);
        }
        public List<NaoConformidade> GetNaoConformidade()
        {
            return _context.NaoConformidade.ToList<NaoConformidade>();
        }

        public NaoConformidade GetNaoConformidade(int id)
        {
            var listagem = _context.NaoConformidade.Where(p => p.Nc_id == id);

            if (listagem.Any())
            {
                return listagem.First();
            }
            else
            {
                return null;
            }
        }

        public void AddNaoConformidade(NaoConformidade naoconformidade)
        {
            _context.NaoConformidade.Add(naoconformidade);
            _context.SaveChanges();
        }

        public void UpdateNaoConformidade(int id, NaoConformidade naoconformidade)
        {
            NaoConformidade ncBase = _context.NaoConformidade.Single(p => p.Nc_id == id);

            if (ncBase != null)
            {
                _context.Attach<NaoConformidade>(ncBase);
                ncBase.Descricao_problema = naoconformidade.Descricao_problema;
                ncBase.Data_problema = naoconformidade.Data_problema;
                ncBase.Causa_raiz = naoconformidade.Causa_raiz;
                ncBase.Causador = naoconformidade.Causador;
                ncBase.Responsavel_tratamento = naoconformidade.Responsavel_tratamento;
                ncBase.Area_impactada = naoconformidade.Area_impactada;
                ncBase.Modelo_veiculo = naoconformidade.Modelo_veiculo;
                ncBase.Marca_veiculo = naoconformidade.Marca_veiculo;
                ncBase.Ano_veiculo = naoconformidade.Ano_veiculo;
                _context.NaoConformidade.Update(ncBase);
                _context.SaveChanges();
            }
        }

        public void DeleteNaoConformidade(int id)
        {
            NaoConformidade ncBase = _context.NaoConformidade.Single(p => p.Nc_id == id);

            if (ncBase != null)
            {
                _context.NaoConformidade.Remove(ncBase);
                _context.SaveChanges();
            }
        }
    }
}
